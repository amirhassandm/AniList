const API = 'https://graphql.anilist.co';
const $ = id => document.getElementById(id);
const form = $('searchForm'), input = $('query'), hint = $('hint');
const grid = $('grid'), statusEl = $('status'), filter = $('statusFilter');
const searchBtn = $('searchBtn'), randomBtn = $('randomBtn'), dialog = $('details');
let current = [];           
let lastSearch = '';         
const MEDIA_QUERY = `
query ($search: String, $status: MediaStatus, $sort: [MediaSort], $page: Int, $perPage: Int) {
  Page(page: $page, perPage: $perPage) {
    media(search: $search, status: $status, type: ANIME, sort: $sort, isAdult: false) {
      id
      title { romaji english }
      coverImage { large }
      averageScore
      episodes
      status
      genres
      description(asHtml: false)
      siteUrl
    }
  }
}`;

const STATUS_LABELS = {
  FINISHED: 'Finished', RELEASING: 'Airing', NOT_YET_RELEASED: 'Not yet aired',
  CANCELLED: 'Cancelled', HIATUS: 'On hiatus'
};

function validate(text){
  const q = text.trim();
  if(!q) return 'Enter an anime title to search.';
  if(q.length < 2) return 'Type at least 2 characters.';
  if(!/[\p{L}\p{N}]/u.test(q)) return 'Use letters or numbers in your search.';
  if(q.length > 100) return 'Keep the title under 100 characters.';
  return '';
}

async function fetchMedia(vars){
  let res;
  try{
    res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ query: MEDIA_QUERY, variables: Object.fromEntries(Object.entries(vars).filter(([, v]) => v != null && v !== '')) })
    });
  }catch(e){
    console.error('AniList fetch failed:', e);
    throw new Error('Could not reach AniList. Check your internet connection and try again.');
  }
  if(res.status === 429) throw new Error('Too many requests. Wait a minute and try again.');
  let json = null;
  try{ json = await res.json(); }catch{}
  if(!res.ok || (json && json.errors)){
    const detail = json && json.errors && json.errors[0] ? json.errors[0].message : 'error ' + res.status;
    console.error('AniList error response:', res.status, json);
    throw new Error('AniList reported a problem: ' + detail);
  }
  return json.data.Page.media || [];
}

function setLoading(msg){
  searchBtn.disabled = randomBtn.disabled = true;
  statusEl.innerHTML = '<span class="spinner"></span>' + esc(msg);
  grid.innerHTML = '';
}
function done(){ searchBtn.disabled = randomBtn.disabled = false; }
const statusVar = () => filter.value || null;

async function searchAnime(q){
  lastSearch = q;
  setLoading('Searching for "' + q + '"...');
  try{
    current = await fetchMedia({ search: q, status: statusVar(), page: 1, perPage: 12 });
    if(!current.length){
      statusEl.textContent = '';
      grid.innerHTML = '<div class="message">No results for "' + esc(q) + '". Check the spelling, try a shorter title, or change the status filter.</div>';
    }else{
      statusEl.textContent = current.length + ' result' + (current.length > 1 ? 's' : '') + ' for "' + q + '".';
      render(current);
    }
  }catch(err){ showError(err.message); }
  finally{ done(); }
}

async function loadTrending(){
  lastSearch = '';
  setLoading('Loading trending anime...');
  try{
    current = await fetchMedia({ status: statusVar(), sort: ['TRENDING_DESC'], page: 1, perPage: 12 });
    statusEl.textContent = current.length ? 'Trending on AniList right now.' : '';
    if(current.length) render(current);
    else grid.innerHTML = '<div class="message">Nothing found for this status filter.</div>';
  }catch(err){ showError(err.message); }
  finally{ done(); }
}

async function randomAnime(){
  setLoading('Picking something random...');
  try{
    const page = Math.floor(Math.random() * 500) + 1;
    current = await fetchMedia({ sort: ['POPULARITY_DESC'], page, perPage: 1 });
    statusEl.textContent = 'Your random pick:';
    render(current);
  }catch(err){ showError(err.message); }
  finally{ done(); }
}

function showError(msg){
  statusEl.textContent = '';
  grid.innerHTML = '<div class="message error">' + esc(msg) + '</div>';
}

function esc(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function info(a){
  const text = (a.description || '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
  return {
    title: a.title.english || a.title.romaji,
    img: (a.coverImage && a.coverImage.large) || '',
    score: a.averageScore ? (a.averageScore / 10).toFixed(1) : 'N/A',
    eps: a.episodes || '?',
    status: STATUS_LABELS[a.status] || 'Unknown',
    genres: a.genres || [],
    synopsis: text || 'No synopsis available.',
    url: /^https:\/\/anilist\.co\//.test(a.siteUrl || '') ? a.siteUrl : ''
  };
}

function render(list){
  grid.innerHTML = list.map((a, i) => {
    const d = info(a);
    return `<button class="card" data-i="${i}" aria-label="View details for ${esc(d.title)}">
      <img src="${esc(d.img)}" alt="Cover of ${esc(d.title)}" loading="lazy">
      <div class="body">
        <h3>${esc(d.title)}</h3>
        <div class="meta"><span class="score">&#9733; ${d.score}</span><span>${d.eps} eps</span><span>${esc(d.status)}</span></div>
        <div class="tags">${d.genres.slice(0, 3).map(g => '<span>' + esc(g) + '</span>').join('')}</div>
        <p class="syn">${esc(d.synopsis)}</p>
      </div></button>`;
  }).join('');
}

function openDetails(i){
  const d = info(current[i]);
  dialog.innerHTML = `<div class="dlg">
    <img src="${esc(d.img)}" alt="Cover of ${esc(d.title)}">
    <div>
      <h3>${esc(d.title)}</h3>
      <div class="meta"><span class="score">&#9733; ${d.score}</span><span>${d.eps} episodes</span><span>${esc(d.status)}</span></div>
      <div class="tags" style="margin-top:10px">${d.genres.map(g => '<span>' + esc(g) + '</span>').join('')}</div>
      <p>${esc(d.synopsis)}</p>
      ${d.url ? `<p><a href="${esc(d.url)}" target="_blank" rel="noopener">View on AniList</a></p>` : ''}
    </div>
    <button class="close btn-ghost" id="closeDlg">Close</button></div>`;
  dialog.showModal();
  $('closeDlg').onclick = () => dialog.close();
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const err = validate(input.value);
  hint.textContent = err;
  input.setAttribute('aria-invalid', err ? 'true' : 'false');
  if(err){ input.focus(); return; }
  searchAnime(input.value.trim());
});
input.addEventListener('input', () => { hint.textContent = ''; input.removeAttribute('aria-invalid'); });
filter.addEventListener('change', () => { lastSearch ? searchAnime(lastSearch) : loadTrending(); });
randomBtn.addEventListener('click', () => { hint.textContent = ''; randomAnime(); });
grid.addEventListener('click', e => {
  const card = e.target.closest('.card');
  if(card) openDetails(+card.dataset.i);
});
dialog.addEventListener('click', e => { if(e.target === dialog) dialog.close(); });

loadTrending(); 